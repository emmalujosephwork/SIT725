const express = require("express");
const UserController = require("../controllers/userController");

const router = express.Router();

router.get("/", UserController.getUsers);
router.post("/users", UserController.addUser);
router.delete("/users/:id", UserController.deleteUser);
router.put("/users/:id", UserController.updateUser);

module.exports = router;