// Function to fetch and display all users
async function fetchUsers() {
    try {
        const response = await fetch('/api/users');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const users = await response.json();
        const userList = document.getElementById('user-list');
        userList.innerHTML = '';
        users.forEach(user => {
            const userDiv = document.createElement('div');
            userDiv.textContent = `${user.name} (${user.email})`;
            userList.appendChild(userDiv);
        });
    } catch (error) {
        console.error('Error fetching users:', error);
    }
}


// Function to delete a user
async function deleteUser(userId) {
    try {
        const response = await fetch(`/api/users/${userId}`, { method: 'DELETE' });
        if (response.ok) {
            alert('User deleted successfully');
            fetchUsers();
        } else {
            alert('Failed to delete user');
        }
    } catch (error) {
        console.error('Error deleting user:', error);
    }
}

// Function to show an edit form for a user
function showEditForm(userId, name, email, phone) {
    const userList = document.getElementById('user-list');
    userList.innerHTML = `
        <h2>Edit User</h2>
        <form onsubmit="updateUser('${userId}'); return false;">
            <label>
                Name:
                <input type="text" id="edit-name" value="${name}" required>
            </label>
            <label>
                Email:
                <input type="email" id="edit-email" value="${email}" required>
            </label>
            <label>
                Phone:
                <input type="text" id="edit-phone" value="${phone}" required>
            </label>
            <button type="submit">Save</button>
        </form>
        <button onclick="fetchUsers()">Cancel</button>
    `;
}

// Function to update a user
async function updateUser(userId) {
    const name = document.getElementById('edit-name').value;
    const email = document.getElementById('edit-email').value;
    const phone = document.getElementById('edit-phone').value;

    try {
        const response = await fetch(`/api/users/${userId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, email, phone }),
        });

        if (response.ok) {
            alert('User updated successfully');
            fetchUsers();
        } else {
            alert('Failed to update user');
        }
    } catch (error) {
        console.error('Error updating user:', error);
    }
}

// Fetch users when the page loads
document.addEventListener('DOMContentLoaded', fetchUsers);