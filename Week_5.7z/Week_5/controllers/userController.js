const UserModel = require("../models/userModel");

const UserController = {
    getUsers: async(req, res) => {
        try {
            const users = await UserModel.getAllUsers();
            res.status(200).json(users);
        } catch (err) {
            res.status(500).send("Error fetching users");
        }
    },
    addUser: async(req, res) => {
        try {
            const { name, email, phone } = req.body;
            if (!name || !email || !phone) {
                return res.status(400).send("All fields are required");
            }
            const result = await UserModel.addUser({ name, email, phone });
            res.status(201).send(`User added with ID: ${result.insertedId}`);
        } catch (err) {
            res.status(500).send("Error adding user");
        }
    },
    deleteUser: async(req, res) => {
        try {
            const { id } = req.params;
            if (!ObjectId.isValid(id)) {
                return res.status(400).send("Invalid ID");
            }
            const result = await UserModel.deleteUser(id);
            res.status(200).send("User deleted");
        } catch (err) {
            res.status(500).send("Error deleting user");
        }
    },
    updateUser: async(req, res) => {
        try {
            const { id } = req.params;
            const { name, email, phone } = req.body;
            const result = await UserModel.updateUser(id, { name, email, phone });
            res.status(200).send("User updated");
        } catch (err) {
            res.status(500).send("Error updating user");
        }
    },
};

module.exports = UserController;